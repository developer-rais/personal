package com.razorpay.model.datatypes;

public abstract  class BaseDataType<T> {
    public abstract  boolean isValid(T t);


}
