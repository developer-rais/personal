package com.razorpay.model.storage;

public class MapBasedStorage<Key, Value> implements Storage<Key, Value> {
    @Override
    public void add(Key o, Value o2) {

    }

    @Override
    public void get(Key o) {

    }

    @Override
    public void remove(Key o) {

    }
}
