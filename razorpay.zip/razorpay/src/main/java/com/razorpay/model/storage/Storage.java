package com.razorpay.model.storage;

public interface Storage<Key,Value> {
    public void add(Key key, Value value);
    public void get(Key key);
    public void remove(Key key);

}
