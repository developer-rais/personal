package com.razorpay.factory;


import com.razorpay.model.datatypes.BaseDataType;
import com.razorpay.model.datatypes.IntegerDataType;

public class DataTypeFactory {

//    public static BaseDataType createDataType(BaseDataType dataType, Object value )
//    {
//        if(dataType instanceof IntegerDataType)
//        {
//            return new IntegerDataType();
//        }
//    }
}
